package com.example.ad_practicaregistro

import android.content.Intent
import android.content.SharedPreferences
import android.media.Image
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.io.Serializable
import java.util.concurrent.CountDownLatch

class ModificarUsuario : AppCompatActivity() {
    lateinit var imagen:ImageView
    lateinit var nombre:EditText
    lateinit var horasVuelo:EditText
    lateinit var contraseña:EditText
    lateinit var fecha:TextView
    lateinit var btn_modificar:Button
    lateinit var btn_baja:Button

    private lateinit var pojo_usuario:Usuario

    private var url_imagen: Uri?=null
    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    lateinit var SP: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_modificar_usuario)
    }

    override fun onStart() {
        super.onStart()

        pojo_usuario=intent.getSerializableExtra("usuario") as Usuario

        imagen = findViewById(R.id.modificar_iv_imagen)
        nombre = findViewById(R.id.modificar_et_username)
        horasVuelo = findViewById(R.id.modificar_et_horasVuelo)
        contraseña = findViewById(R.id.modificar_et_password)
        fecha=findViewById(R.id.modificar_tv_fecha)
        btn_modificar = findViewById(R.id.modificar_btn_modificar)
        //btn_baja = findViewById(R.id.modificar_btn_darDeBaja)

        val app_id = "com.example.ad_practicaregistro"
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)

        var loged = SP.getString("usuario","1")
        var tipo_user = SP.getString("tipo","normal")
        if(loged==""){
            val intent = Intent(applicationContext,MainActivity::class.java)
            this.startActivity(intent)
        }

        Glide.with(applicationContext).load(pojo_usuario.url_imagen).into(imagen)
        nombre.setText(pojo_usuario.nombre)
        contraseña.setText(pojo_usuario.contraseña)
        horasVuelo.setText(pojo_usuario.horasVuelo.toString())
        fecha.setText(pojo_usuario.fecha)

        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        imagen.setOnClickListener{
            obtener_url.launch("image/*")
        }

        btn_modificar.setOnClickListener{
            if(nombre.text.toString().trim().equals("") ||
                horasVuelo.text.toString().trim().equals("") ||
                contraseña.text.toString().trim().equals("")) {

                Toast.makeText(applicationContext, "No puedes dejar datos vacios", Toast.LENGTH_SHORT).show()
            }else if(horasVuelo.text.toString().trim().toIntOrNull()==null || horasVuelo.text.toString().toInt()<=0){
                Toast.makeText(applicationContext, "Las horas de vuelo tienen que ser mas de 0", Toast.LENGTH_SHORT).show()
            }else{
                var url_imagen_firebase:String?=pojo_usuario.url_imagen

                GlobalScope.launch(Dispatchers.IO) {
                    if(!nombre.text.toString().trim().equals(pojo_usuario.nombre) && existe_usuario(nombre.text.toString().trim())){
                        tostadaCorrutina("El usuario ya existe en la base de datos")
                    }else{
                        if(url_imagen!=null){
                            url_imagen_firebase=editarImagen(pojo_usuario.id!!,url_imagen!!)
                        }

                        editarUsuario(pojo_usuario.id!!,
                            nombre.text.toString().trim(),
                            contraseña.text.toString().trim(),
                            pojo_usuario.tipo.toString(),
                            url_imagen_firebase!!,
                            pojo_usuario.fecha.toString(),
                            horasVuelo.text.toString().toInt(),
                            pojo_usuario.estado.toString().toInt()
                        )
                        if(tipo_user=="admin"){
                            val intent = Intent(applicationContext,VerUsuarios::class.java)
                            intent.putExtra("usuario", pojo_usuario as Serializable)
                            startActivity(intent)
                        }else {
                            val intent = Intent(applicationContext, Infouser::class.java)
                            intent.putExtra("usuario", pojo_usuario as Serializable)
                            startActivity(intent)
                        }
/*
                        if(tipo_user=="admin") {
                            tostadaCorrutina("Avion modificado")
                            val actividad = Intent(applicationContext, VerUsuarios::class.java)
                            startActivity(actividad)
                        }else{
                            recreate()
                        }*/
                    }
                }
            }
        }

/*
        btn_baja.setOnClickListener{
            sto_ref.child("hangar").child("imagenes").child(pojo_usuario.id!!).delete()
            db_ref.child("hangar").child("aviones").child(pojo_usuario.id!!).removeValue()

            Toast.makeText(applicationContext, "Avion borrado con exito", Toast.LENGTH_SHORT).show()
/*
            if(tipo_user=="normal") {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }else{
                val intent = Intent(this, VerUsuarios::class.java)
                startActivity(intent)
            }*/
        }*/


    }

    private fun existe_usuario(nombre:String):Boolean{
        var resultado:Boolean?=false

        val semaforo= CountDownLatch(1)
        db_ref.child("hangar")
            .child("pilotos")
            .orderByChild("nombre")
            .equalTo(nombre)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if(snapshot.getValue(Usuario::class.java)!=null){
                        resultado=true;
                    }
                    semaforo.countDown()
                }

                override fun onCancelled(error: DatabaseError) {
                    println(error.message)
                }
            })

        semaforo.await();

        return resultado!!;
    }

    private suspend fun editarImagen(id:String,imagen:Uri):String{
        var url_imagen_firebase:Uri?=null

        url_imagen_firebase=sto_ref.child("hangar").child("fotos").child(id)
            .putFile(imagen).await().storage.downloadUrl.await()

        return url_imagen_firebase.toString()
    }

    private fun editarUsuario(id:String,nombre:String,contraseña:String,tipo:String,url_imagen:String,fecha:String,horasVuelo:Int,estado:Int){
        val nuevo_usuario= Usuario(
            id,
            nombre,
            contraseña,
            tipo,
            url_imagen,
            fecha,
            horasVuelo,
            estado
        )
        db_ref.child("hangar").child("pilotos").child(id).setValue(nuevo_usuario)

    }




    private val obtener_url= registerForActivityResult(ActivityResultContracts.GetContent()){
            uri:Uri?->
        when (uri){
            null-> Toast.makeText(applicationContext,"No has seleccionado ninguna imagen", Toast.LENGTH_SHORT).show()
            else->{
                url_imagen=uri
                imagen.setImageURI(url_imagen)
                Toast.makeText(applicationContext,"Has seleccionado una nueva imagen", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun tostadaCorrutina(texto:String){
        runOnUiThread{
            Toast.makeText(
                applicationContext,
                texto,
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}