package com.example.ad_practicaregistro

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.Serializable

class MainActivity : AppCompatActivity() {
    private lateinit var contexto: Context

    lateinit var SP: SharedPreferences

    lateinit var username:EditText
    lateinit var password:EditText
    lateinit var login:Button
    lateinit var createAccount:TextView

    private lateinit var db_ref: DatabaseReference
    private lateinit var sto_ref: StorageReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()
        username=findViewById(R.id.main_et_username)
        password=findViewById(R.id.main_et_password)
        login=findViewById(R.id.main_btn_login)
        createAccount=findViewById(R.id.main_tv_createAccount)

        val app_id = "com.example.ad_practicaregistro"
        val sp_name = "${app_id}_practica"
        SP = getSharedPreferences(sp_name, 0)

        var loged = SP.getString("usuario","1")
        var tipo_user =SP.getString("tipo","normal")


        db_ref= FirebaseDatabase.getInstance().getReference()
        sto_ref= FirebaseStorage.getInstance().getReference()

        createAccount.setOnClickListener{
            val intent = Intent(this,Registro::class.java)
            startActivity(intent)
        }

        login.setOnClickListener {
            if (username.text.toString().trim() == "") {
                username.error = "Introduce un usuario"
            } else if (password.text.toString().trim() == "") {
                password.error = "Introduce la contraseña"
            } else {
                db_ref.child("hangar").child("pilotos")
                    .orderByChild("nombre").equalTo(username.text.toString().trim())
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            if (snapshot.hasChildren()) {
                                val pojo_usuario = snapshot.children.iterator().next()
                                    .getValue(Usuario::class.java)
                                if (pojo_usuario?.contraseña.equals(
                                        password.text.toString().trim()
                                    )
                                ) {
                                    val intent:Intent
                                    if (pojo_usuario?.tipo == "normal") {
                                        intent = Intent(applicationContext, Infouser::class.java)
                                        intent.putExtra("usuario", pojo_usuario as Serializable)
                                    } else {
                                        intent = Intent(applicationContext, VerUsuarios::class.java)
                                        intent.putExtra("usuario", pojo_usuario as Serializable)
                                    }
                                    with(SP.edit()){
                                        putString("usuario", pojo_usuario?.nombre.toString())
                                        putString("tipo",pojo_usuario?.tipo.toString())

                                        commit()
                                    }
                                    startActivity(intent)
                                } else {
                                    Toast.makeText(
                                        applicationContext,
                                        "Contraseña incorrecta",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else {
                                Toast.makeText(
                                    applicationContext,
                                    "No existe el usuario",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(
                                applicationContext,
                                "Error en el login",
                                Toast.LENGTH_SHORT
                            ).show()
                        }

                    })
            }
        }
    }
}